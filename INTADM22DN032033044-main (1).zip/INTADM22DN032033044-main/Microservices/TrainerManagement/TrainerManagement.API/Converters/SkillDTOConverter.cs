﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TrainerManagement.API.DTOs;
using TrainerManagement.Domain.Aggregates.TrainerAggregate;
using TrainerManagement.Domain.ValueObjects;

namespace TrainerManagement.API.Converters
{
    public class SkillDTOConverter
    {
        public static Skill ToSkill(SkillDTO dto)
        {
            return new Skill(dto.Name, new SkillExpertise(dto.Expertise, dto.YearsOfExperience)) { Id = dto.Id };
        }
        public static SkillDTO ToSkillDTO(Skill skill)
        {
            return new SkillDTO
            {
                Id = skill.Id,
                Name = skill.Name,
                Expertise = skill.SkillExpertise.Expertise,
                YearsOfExperience = skill.SkillExpertise.YearsOfExperience
            };
        }
    }
}
