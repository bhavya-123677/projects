import { useState } from "react"

export function FilterProducts(props) {
    const [productName, setProductName] = useState('');
    const handleNameChange = ev =>{
        setProductName(ev.target.value);
    }
    const handleSubmit = ev => {
        ev.preventDefault();
        props.onFilter(productName);
    }
    const handleReset = ev =>{
        ev.preventDefault();
        setProductName('');
        props.onFormReset();
    }
    return <div className="row">
        <div className="col-12">
            <form method="post" onSubmit={handleSubmit} onReset={handleReset}>
                <div className="row">
                    <div className="col">
                        <input type="text"
                            className="form-control"
                            id="productName" 
                            name="productName"
                            placeholder="Product name"
                            value={productName}
                            onChange={handleNameChange} />
                    </div>
                    <div className="col">
                        <button type="submit"
                            className="btn btn-primary">
                            Search
                        </button>
                    </div>
                    <div className="col">
                        <button type="reset"
                            className="btn btn-secondary">
                            Reset
                        </button>
                    </div>
                </div>




            </form>
        </div>
    </div>
}