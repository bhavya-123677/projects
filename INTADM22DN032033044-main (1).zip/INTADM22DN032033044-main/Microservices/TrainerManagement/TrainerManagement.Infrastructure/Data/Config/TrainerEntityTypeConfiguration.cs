﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using TrainerManagement.Domain.Aggregates.TrainerAggregate;

namespace TrainerManagement.Infrastructure.Data.Config
{
    public class TrainerEntityTypeConfiguration : IEntityTypeConfiguration<Trainer>
    {
        public void Configure(EntityTypeBuilder<Trainer> builder)
        {
            builder.HasKey(p => p.Id);
            builder.Property(p => p.Fullname).HasMaxLength(30).IsRequired(true);
            builder.Property(p => p.Email).HasMaxLength(50).IsRequired(true);
            builder.Property(p => p.PhoneNumber).HasMaxLength(10).IsFixedLength(true).IsRequired(true);
            builder.Property(p => p.Location).HasMaxLength(30).IsRequired(true);
        }
    }
}
