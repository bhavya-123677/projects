import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import TrainersService from "../services/TrainersService";

const TrainerDetails = props => {
    let { trainerId } = useParams();
    const [trainer, setTrainer] = useState({});
    useEffect(() => {
        TrainersService.getTrainerById(trainerId).then(res => {
            setTrainer({ ...res.data });
        }).catch(err => {
            alert(err.response.statusText);
        });
    }, []);
    const getExpertise = num => {

        let expertise = '';
        switch (num) {
            case 0: expertise = 'Beginner'; break;
            case 1: expertise = 'Intermediate'; break;
            case 2: expertise = 'Advanced'; break;
        }
        return expertise;
    }
    const handleSkillDelete = skillid => {
        const confirmDelete = window.confirm('Are you sure you want to delete?');
        if (confirmDelete) {
            TrainersService.removeSkill(trainer.id, skillid).then(res => {
                alert('Skill remove successfully');
                const skills = [...trainer.skills];
                const currentSkills = skills.filter(s=>s.id!==skillid);
                setTrainer({...trainer, skills: currentSkills});
            }).catch(res => {

            });
        }
    }
    return <div className="row">
        <div className="col-12">
            <h2>Trainer Details</h2>
            <dl>
                <dt>ID</dt>
                <dd>{trainer.id}</dd>
                <dt>Full Name</dt>
                <dd>{trainer.fullname}</dd>
                <dt>Email</dt>
                <dd>{trainer.email}</dd>
                <dt>Phone Number</dt>
                <dd>{trainer.phoneNumber}</dd>
                <dt>Location</dt>
                <dd>{trainer.location}</dd>
            </dl>
            <table className="table">
                <thead>
                    <tr>
                        <th>Skill Id</th>
                        <th>Skill name</th>
                        <th>Expertise</th>
                        <th>Exp In Yrs</th>
                        {props.role==='Lead' && <th>Delete</th>}
                    </tr>
                </thead>
                <tbody>
                    {trainer.skills?.map(s => <tr key={s.id}>
                        <td>{s.id}</td>
                        <td>{s.name}</td>
                        <td>{getExpertise(s.expertise)}</td>
                        <td>{s.yearsOfExperience}</td>
                        {props.role==='Lead' && <td>
                            
                            <button className="btn btn-sm btn-danger" 
                        onClick={()=>handleSkillDelete(s.id)}>Delete</button>
                
                        </td>}
                    </tr>)}
                </tbody>
            </table>
        </div>
    </div>
}
export default TrainerDetails;