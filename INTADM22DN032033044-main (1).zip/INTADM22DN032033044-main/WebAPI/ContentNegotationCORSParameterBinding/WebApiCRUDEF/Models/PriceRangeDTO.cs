﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiCRUDEF.Models
{
    public class PriceRangeDTO
    {
        public decimal Min { get; set; }
        public decimal Max { get; set; }
    }
}
