﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCRUDEF.Specifications;
namespace WebApiCRUDEF.Repositories
{
    public interface IRepository<TEntity> where TEntity : class
    {
        TEntity Add(TEntity item);
        TEntity Update(TEntity item);
        TEntity Remove(TEntity item);
        IReadOnlyCollection<TEntity> GetAll();
        Task<TEntity> GetByIdAsync(int id);
        Task<int> SaveAsync();
        IReadOnlyCollection<TEntity> GetBySpec(SpecificationBase<TEntity> spec);
    }
}
