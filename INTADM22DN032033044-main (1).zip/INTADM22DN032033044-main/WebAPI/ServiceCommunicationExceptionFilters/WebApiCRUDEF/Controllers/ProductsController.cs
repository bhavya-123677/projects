﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCRUDEF.Models;
using WebApiCRUDEF.Repositories;
using WebApiCRUDEF.Specifications;
using Confluent.Kafka;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using WebApiCRUDEF.Filters;
namespace WebApiCRUDEF.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [TypeFilter(typeof(MyUnHandledExceptionFilter))]
    public class ProductsController : ControllerBase
    {
        private readonly IRepository<Product> productRepository;
        private readonly IConfiguration configuration;
        public ProductsController(IRepository<Product> productRepository, IConfiguration configuration)
        {
            this.productRepository = productRepository;
            this.configuration = configuration;
        }

        [HttpGet]
        [ProducesResponseType(200, Type = typeof(List<Product>))]
        [AllowAnonymous]
        public IActionResult GetProducts()
        {
            throw new NotImplementedException("Method is not implemented");
            //var result = productRepository.GetAll();
            //return Ok(result);
        }

        [HttpGet("{id}")]
        [ProducesResponseType(404)]
        [ProducesResponseType(200, Type = typeof(Product))]
        [AllowAnonymous]
        public async Task<IActionResult> GetProduct(int id)
        {
            var product = await productRepository.GetByIdAsync(id);
            if (product == null)
                return NotFound();

            return Ok(product);
        }

        [HttpPost]
        [ProducesResponseType(400)]
        [ProducesResponseType(201)]
        [Authorize(Roles ="Employees")]
        public async Task<IActionResult> SaveProduct(Product obj)
        {
            productRepository.Add(obj);
            await productRepository.SaveAsync();
            return StatusCode(201);
        }

        [HttpPut]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200, Type = typeof(Product))]
        [Authorize(Roles ="Admin,Employees")]
        public async Task<IActionResult> UpdateProduct(Product obj)
        {
            var product = await productRepository.GetByIdAsync(obj.Id);
            if (product == null)
                return NotFound();
            if (product.Price > obj.Price)
            {
                string json = JsonConvert.SerializeObject(obj);
                string kafkaurl = configuration["KafkaServerUrl"];
                string topicname = configuration["KafkaQ"];
                var config = new ProducerConfig { BootstrapServers = kafkaurl };
                using (var producer = new ProducerBuilder<Null, string>(config).Build())
                {
                    var message = new Message<Null, string>();
                    message.Value = json;
                    await producer.ProduceAsync(topicname, message);
                }
            }
            product.Name = obj.Name;
            product.Price = obj.Price;
            productRepository.Update(product);
            await productRepository.SaveAsync();
            return Ok(product);
        }

        [HttpDelete("{id}")]
        [ProducesResponseType(404)]
        [ProducesResponseType(204)]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await productRepository.GetByIdAsync(id);
            if (product == null)
                return NotFound();
            productRepository.Remove(product);
            await productRepository.SaveAsync();

            return NoContent();
        }

        [HttpGet("filter")]
        [ProducesResponseType(200, Type = typeof(List<Product>))]
        public IActionResult FilterProductsByPrice([FromQuery] PriceRangeDTO priceRange)
        {
            var spec = new FilterProductsByPriceRangeSpecification(priceRange.Min, priceRange.Max);
            var Data = productRepository.GetBySpec(spec);
            return Ok(Data);
        }

        [HttpPost("filterByName")]
        [ProducesResponseType(200, Type = typeof(List<Product>))]
        public IActionResult FilterByName([FromBody] string productName)
        {
            var spec = new SearchProductByNameSpecification(productName);
            var Data = productRepository.GetBySpec(spec);
            return Ok(Data);
        }

    }
}
