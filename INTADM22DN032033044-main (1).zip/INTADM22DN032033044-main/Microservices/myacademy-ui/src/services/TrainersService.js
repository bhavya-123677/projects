import axios from "axios";


const http = axios.create({
    headers: { 'content-type': 'application/json', 'Authorization': '' },
    baseURL: 'http://localhost:61940/'
});

http.interceptors.request.use(config => {
    const token = window.localStorage.getItem('apitoken');
    config.headers['Authorization'] = 'Bearer ' + token;
    return config;
}, error => {
    Promise.reject(error);
});

//http.interceptors.response.use()

const getTrainers = () => {
    return http.get('api/trainers');
}
const getTrainerById = id =>{
    return http.get('api/trainers/'+id);
}
const removeSkill = (trainerId, skillId) => {
    return http.delete(`api/trainers/${trainerId}/deleteskill/${skillId}`);
}
const addNewTrainer = trainerObj => {
    return http.post('api/trainers', trainerObj);
}

let TrainersService = { getTrainers, getTrainerById, removeSkill, addNewTrainer };
export default TrainersService;