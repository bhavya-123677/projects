import { Link } from 'react-router-dom';
export function NavBar(props) {
    return <nav className="navbar navbar-expand-lg navbar-dark bg-dark">

        <a className="navbar-brand" href="#">MyApp</a>
       
            <ul className="navbar-nav mr-auto">
                <li className="nav-item">
                    <Link to='/' className="nav-link">Products List</Link>
                </li>
                <li className="nav-item">
                    <Link to='/add-product' className="nav-link">Add Product</Link>
                </li>
                <li className="nav-item">
                    <Link to='/likes' className="nav-link">Likes</Link>
                </li>
               

            </ul>

    </nav>
}