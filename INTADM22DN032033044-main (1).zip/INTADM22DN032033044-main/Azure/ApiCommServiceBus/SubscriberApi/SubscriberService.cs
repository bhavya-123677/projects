﻿using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SubscriberApi
{
    public class SubscriberService : IHostedService
    {
        private readonly IConfiguration configuration;
        private readonly string conn;
        private readonly ServiceBusClient client;
        private ServiceBusProcessor busProcessor;
        public SubscriberService(IConfiguration configuration)
        {
            this.configuration = configuration;
            this.conn = this.configuration["AzSBCon"];
            this.client = new ServiceBusClient(this.conn);
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            var options = new ServiceBusProcessorOptions { MaxConcurrentCalls = 1, AutoCompleteMessages = false };
            busProcessor = client.CreateProcessor("demoq", options);
            busProcessor.ProcessMessageAsync += BusProcessor_ProcessMessageAsync;
            busProcessor.ProcessErrorAsync += BusProcessor_ProcessErrorAsync;
            await busProcessor.StartProcessingAsync().ConfigureAwait(false);
        }

        private Task BusProcessor_ProcessErrorAsync(ProcessErrorEventArgs arg)
        {
            Console.WriteLine("Error in processing data");
            Console.WriteLine(arg.Exception.Message);
            return Task.CompletedTask;
        }

        private Task BusProcessor_ProcessMessageAsync(ProcessMessageEventArgs arg)
        {
            var obj = arg.Message.Body.ToObjectFromJson<Demo>();
            Console.WriteLine($"ID={obj.Id}, Name={obj.Name}");
            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            busProcessor.StopProcessingAsync().ConfigureAwait(false);
            client.DisposeAsync().ConfigureAwait(false);
            return Task.CompletedTask;
        }
    }
}
