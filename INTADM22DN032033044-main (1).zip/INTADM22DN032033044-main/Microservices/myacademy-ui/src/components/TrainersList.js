import { useEffect, useState } from 'react';
import TrainersService from '../services/TrainersService';
import { Link } from 'react-router-dom';
const TrainersList = props => {
    const [trainers, setTrainers] = useState([]);
    useEffect(() => {
        TrainersService.getTrainers().then(res => {
            console.log(res.data);
            setTrainers([...res.data]);
        }).catch(err => {
            alert(err.response.statusText);
        });
    }, [trainers.length])
    
    return <div className='row'>
        <div className='col-12'>
            <h2>Trainers List</h2>
            <table className='table'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Primary Skill</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Location</th>
                        <th>DOJ</th>
                        <th>Active</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {trainers.map(t => <tr key={t.id}>
                        <td>{t.id}</td>
                        <td>{t.fullname}</td>
                        <td>{t.primarySkill}</td>
                        <td>{t.email}</td>
                        <td>{t.phoneNumber}</td>
                        <td>{t.location}</td>
                        <td>{t.dateOfJoining}</td>
                        <td>{t.isActive}</td>
                        <td>
                            <Link to={'/trainer/' + t.id}>Details</Link>
                        </td>
                    </tr>)}
                </tbody>
            </table>
        </div>
    </div>
}
export default TrainersList;