﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCRUDEF.Models;

namespace WebApiCRUDEF.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ShopContext context;
        public ProductsController(ShopContext ctx)
        {
            this.context = ctx;
        }
        [HttpGet]
        public IActionResult GetProducts()
        {
            var query = from item in context.Products
                        select item;
            var result = query.ToList();
            return Ok(result);
        }
        [HttpGet("{id}")]
        public IActionResult GetProduct(int id)
        {
            var product = context.Products.Find(id);
            if (product == null)
                return NotFound();

            return Ok(product);
        }

        [HttpPost]
        public IActionResult SaveProduct(Product obj)
        {
            context.Products.Add(obj);
            context.SaveChanges();
            return StatusCode(201);
        }

        [HttpPut]
        public IActionResult UpdateProduct(Product obj)
        {
            var product = context.Products.Find(obj.Id);
            if (product == null)
                return NotFound();

            product.Name = obj.Name;
            product.Price = obj.Price;
            context.SaveChanges();
            return Ok(product);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            var product = context.Products.Find(id);
            if (product == null)
                return NotFound();
            context.Products.Remove(product);
            context.SaveChanges();

            return NoContent();
        }
    }
}
