﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TrainerManagement.API.DTOs
{
    public class TrainerDTO
    {
        public long Id { get; set; }
        [Required, StringLength(30)]
        public string Fullname { get;  set; }
        [Required, StringLength(50), EmailAddress]
        public string Email { get;  set; }
        [Required, RegularExpression(@"^[\d]{10}$")]
        public string PhoneNumber { get;  set; }
        [Required, StringLength(30)]
        public string Location { get;  set; }
        public DateTime DateOfJoining { get;  set; }
        public bool IsActive { get;  set; }
        [Required, StringLength(30)]
        public string PrimarySkill { get;  set; }

        public List<SkillDTO> Skills { get; set; } = new List<SkillDTO>();
    }
}
