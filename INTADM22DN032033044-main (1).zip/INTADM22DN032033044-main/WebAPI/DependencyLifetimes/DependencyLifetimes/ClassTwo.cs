﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DependencyLifetimes
{
    public class ClassTwo
    {
        private readonly ClassDep dep;
        public ClassTwo(ClassDep d)
        {
            this.dep = d;
        }
        public int GetIntanceCount()
        {
            return ClassDep.totalinstances;
        }
    }
}
