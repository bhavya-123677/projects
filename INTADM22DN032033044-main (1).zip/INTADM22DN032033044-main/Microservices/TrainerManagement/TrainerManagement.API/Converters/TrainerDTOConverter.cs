﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TrainerManagement.API.DTOs;
using TrainerManagement.Domain.Aggregates.TrainerAggregate;

namespace TrainerManagement.API.Converters
{
    public class TrainerDTOConverter
    {
        public static Trainer ToTrainer(TrainerDTO dto)
        {
            return new Trainer(dto.Fullname,
                dto.PhoneNumber, dto.Email, dto.Location, dto.DateOfJoining, dto.IsActive, dto.PrimarySkill)
            { Id = dto.Id };
        }
        public static TrainerDTO ToTrainerDTO(Trainer trainer)
        {
            return new TrainerDTO
            {
                Id = trainer.Id,
                Fullname = trainer.Fullname,
                Email = trainer.Email,
                PhoneNumber = trainer.PhoneNumber,
                DateOfJoining = trainer.DateOfJoining,
                IsActive = trainer.IsActive,
                Location = trainer.Location,
                PrimarySkill = trainer.PrimarySkill
            };
        }
    }
}
