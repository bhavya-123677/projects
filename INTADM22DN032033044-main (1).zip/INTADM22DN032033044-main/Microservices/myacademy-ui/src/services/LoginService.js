import axios from 'axios';
const http = axios.create({
    headers: { 'content-type': 'application/json' },
    baseURL: 'http://localhost:13407'
});

const doLogin = loginCredentails => {
    return http.post('/api/auth', loginCredentails);
}

let LoginService = {doLogin};
export default LoginService;