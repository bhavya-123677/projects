﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using TrainerManagement.Domain.Specifications;

namespace TrainerManagement.Domain.Aggregates.TrainerAggregate
{
    public class SearchByIdAndIncludeSkillsSpecification : SpecificationBase<Trainer>
    {
        private readonly long trainerId;
        public SearchByIdAndIncludeSkillsSpecification(long trainerid)
        {
            this.trainerId = trainerid;
            base.Includes.Add("SecondarySkills");
        }

        public override Expression<Func<Trainer, bool>> ToExpression()
        {
            return obj => obj.Id == trainerId;
        }
    }
}
