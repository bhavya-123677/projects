import { useState } from "react";
import axios from "axios";
import Success from './SuccessComponent';
import Error from './ErrorComponent';
export function AddProduct(props) {
    const [formData, setFormData] = useState({ productname: '', productprice: 0 })
    const [notification, setNotification] = useState({ type: '', message: '' });
    let notificationComponent = null;
    switch (notification.type) {
        case 'Success':
            notificationComponent = <Success successMessage={notification.message} />; break;
        case 'Error':
            notification = <Error errorMessage={notification.message} />;
            break;
    }
    const handleSubmit = ev => {
        ev.preventDefault();
        const productObj = { name: formData.productname, price: formData.productprice };
        console.log(productObj);
        axios.post('http://localhost:18236/api/products', productObj)
            .then(res => {
                if(res.status==201){
                    setNotification({ type: 'Success', message: 'Product added successfully' })
                }
            })
            .catch(err => {
                alert(err.response.status);
            });
    }
    const handleChange = e => {
        let { name, value, type } = e.target;
        if (type === "number")
            value = parseFloat(value);
        setFormData({ ...formData, [name]: value });
    }
    return <div className="row">
        <div className="col-md-5">
            <h1>Add New Product</h1>
            {notificationComponent}
            <form method="post" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="productname">Enter product name</label>
                    <input type="text"
                        id="productname"
                        name="productname"
                        className="form-control"
                        value={formData.productname}
                        onChange={handleChange}
                        required />
                </div>
                <div className="form-group">
                    <label htmlFor="productprice">Enter product price</label>
                    <input type="number"
                        id="productprice"
                        name="productprice"
                        className="form-control"
                        value={formData.productprice}
                        onChange={handleChange}
                    />
                </div>

                <div className="form-group mt-4">
                    <button type="submit" className="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
}