﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using Azure.Core;
using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using StorageClientApp.Models;

namespace StorageClientApp.Controllers
{
    public class StorageAccountController : Controller
    {
        private readonly IConfiguration configuration;
        private readonly string storageConnection;
        private readonly BlobServiceClient client;
        public StorageAccountController(IConfiguration configuration)
        {
            this.configuration = configuration;
            this.storageConnection = this.configuration["StorageAccountConnection"];
            this.client = new BlobServiceClient(this.storageConnection);
        }
        public async Task<IActionResult> Index()
        {
            List<string> containerNames = new List<string>();
            await foreach(var container in client.GetBlobContainersAsync())
            {
                containerNames.Add(container.Name);
            }
            return View(containerNames);
        }

        [Route("[controller]/[action]/{containerName}")]
        public async Task<IActionResult> Blobs(string containerName)
        {
            List<string> blobNames = new List<string>();
            var container = client.GetBlobContainerClient(containerName);
            await foreach(var blob in container.GetBlobsAsync())
            {
                blobNames.Add(blob.Name);
            }
            return View(blobNames);
        }

        [Route("[controller]/[action]/{blobName}/{containerName}")]
        public async Task<IActionResult> Download(string blobName, string containerName)
        {
            var container = client.GetBlobContainerClient(containerName);
            var blob = container.GetBlobClient(blobName);
            var response = await blob.DownloadContentAsync();
            var stream = response.Value.Content.ToStream();
            return File(stream, response.Value.Details.ContentType);
        }

        public async Task<IActionResult> CreateContainer(string NewContainerName)
        {
            var response = await client.CreateBlobContainerAsync(NewContainerName);
            if (response.Value.Exists())
                ModelState.AddModelError("", "Already present");
            return RedirectToAction("Index");
        }

        [Route("[controller]/[action]/{containerName}")]
        public IActionResult UploadBlob(string containerName)
        {
            return View();
        }

        [Route("[controller]/[action]/{containerName}")]
        [HttpPost]
        public async Task<IActionResult> UploadBlob(string containerName, UploadViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var container = client.GetBlobContainerClient(containerName);
            var filename = $"{model.BlobName}{System.IO.Path.GetExtension(model.File.FileName)}";
            var blob = container.GetBlobClient(filename);
            if (blob.Exists())
                ModelState.AddModelError("", "File already present with given name");
            var response = await blob.UploadAsync(model.File.OpenReadStream());
            return RedirectToAction("Blobs", new { containerName = containerName });
        }
    }
}
