﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Confluent.Kafka;
namespace PricesSlashedConsumerApp
{
    public class KafkaConsumerService : BackgroundService
    {
        private readonly IConsumer<Null, string> consumer;
        public KafkaConsumerService()
        {
            var config = new ConsumerConfig
            {
                GroupId = "PricesSlashedConsumer",
                BootstrapServers = "localhost:9092",
                AutoOffsetReset = AutoOffsetReset.Earliest
            };
            consumer = new ConsumerBuilder<Null, string>(config).Build();
            consumer.Subscribe("PriceSlashed");
        }
        protected async override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await Task.Yield();
            while(!stoppingToken.IsCancellationRequested)
            {
                var result = consumer.Consume();
                var obj = JsonConvert.DeserializeObject<Product>(result.Message.Value);
                Console.WriteLine("Sending emails to customer about slashed prices of product");
                Console.WriteLine($"{obj.Id}, {obj.Name}, {obj.Price}");
            }
        }
    }
}
