 const FilterTrainersForm = props => {
    return <h1>FilterTrainersForm component</h1>
}
export default FilterTrainersForm;