﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using TrainerManagement.Domain.Specifications;

namespace TrainerManagement.Domain.Aggregates.TrainerAggregate
{
    public class SearchBySkillSpecification : SpecificationBase<Trainer>
    {
        private readonly string skill;
        public SearchBySkillSpecification(string skill)
        {
            this.skill = skill;
        }
        public override Expression<Func<Trainer, bool>> ToExpression()
        {
            return obj => obj.PrimarySkill.ToLower().Equals(skill.ToLower());
        }
    }
}
