import Product from "./ProductComponent"
import axios from "axios";
import { useEffect, useState } from "react";
import { FilterProducts } from "./FilterProductsComponent";
function ProductList() {

    const [products, setProducts] = useState([]);

    useEffect(() => {
        getAllProducts();
    }, []);

    const getAllProducts = () => {
        axios.get('http://localhost:18236/api/products').then(r => {
            console.log(r.status);
            console.log(r.data);
            setProducts([...r.data]);
        }).catch(e => {
            console.log(e.response.status);
            alert(e.response.statusText);
        });
    }

    const deleteProduct = pid => {
        axios.delete('http://localhost:18236/api/products/' + pid)
            .then(r => {
                getAllProducts();
            })
            .catch(r => {
                console.log(r);
            });
    }
    let productComponents = products.map(p =>
        <div className="col-md-4 mt-4" key={p.id}>
            <Product prod={p} onProductDelete={deleteProduct} />
        </div>)

    const getProductsByName = name => {
        console.log(name);
        const obj = JSON.stringify(name);
        const config= {headers: {'content-type': 'application/json'}};
        console.log(obj);
        axios.post('http://localhost:18236/api/products/filterbyname', obj, config)
            .then(r => {
                setProducts([...r.data]);
            })
            .catch(e => { });
    }
    return <div className="container">
        <h1>Products Details</h1>
        <FilterProducts onFilter={getProductsByName} onFormReset={getAllProducts} />
        <div className="row">
            {productComponents}
        </div>
    </div>
}
export default ProductList;