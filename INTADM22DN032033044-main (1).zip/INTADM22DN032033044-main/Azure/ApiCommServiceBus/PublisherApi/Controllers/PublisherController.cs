﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Azure.Messaging.ServiceBus;
using System.Text.Json;

namespace PublisherApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PublisherController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private readonly string conn;
        private readonly ServiceBusClient client;
        public PublisherController(IConfiguration configuration)
        {
            this.configuration = configuration;
            this.conn = this.configuration["AzSBCon"];
            this.client = new ServiceBusClient(this.conn);
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var obj = new { Id = 101, Name = Guid.NewGuid().ToString() };
            var json = JsonSerializer.Serialize(obj);
            var sender = client.CreateSender("demoq");
            var message = new ServiceBusMessage(json);
            await sender.SendMessageAsync(message);
            return Ok(obj);
        }
    }
}
