// function Like() {

import React, { useState } from "react";

// }
// export default Like;

// export function Like() {
//     const [likes, setLikes] = useState({ count: 100, liked: false })
//     const handleClick = e => {
//         e.preventDefault();
//         let prevLikesCount = likes.count;
//         let prevLikedState = likes.liked;
//         let newCount = 0;
//         let newLikedState = false;
//         if (prevLikedState == true) {
//             newLikedState = false;
//             newCount = prevLikesCount - 1;
//         }
//         else {
//             newLikedState =true;
//             newCount = prevLikesCount+1;
//         }
//         setLikes({ ...likes, count: newCount, liked: newLikedState });
//     }
//     return (
//         <form method="post" onSubmit={handleClick}>
//             {/* <button type="submit" onClick={handleClick}>Like</button> */}
//             <button type="submit">
//                 Total Likes : {likes.count} | {likes.liked == false ? 'Like' : 'Liked'}</button>
//         </form>
//     );
// }

export class Like extends React.Component {
    constructor(props) {
        super(props);
        this.state = { count: 200, liked: false }
    }
    handleClick = e => {
        e.preventDefault();
        let prevLikesCount = this.state.count;
        let prevLikedState = this.state.liked;
        let newCount = 0;
        let newLikedState = false;
        if (prevLikedState == true) {
            newLikedState = false;
            newCount = prevLikesCount - 1;
        }
        else {
            newLikedState =true;
            newCount = prevLikesCount+1;
        }
        this.setState({ ...this.state, count: newCount, liked: newLikedState });
    }
    render() {
        return <form method="post" onSubmit={this.handleClick}>
            <button type="submit">
                Total Likes {this.state.count} | 
                {this.state.liked == false ? 'Like' : 'Liked'}
            </button>
        </form>
    }
}