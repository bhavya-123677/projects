﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit;
using NUnit.Framework;
using TrainerManagement.API;
using TrainerManagement.API.Controllers;
using TrainerManagement.Domain.Entities;
using TrainerManagement.Domain.Interfaces;
using TrainerManagement.API.DTOs;
using Moq;
using TrainerManagement.Domain.Aggregates.TrainerAggregate;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace TrainerManagement.API.Tests
{
    [TestFixture]
    public class TrainersControllerShould
    {
        [Test]
        public async Task Return_201StatusCode()
        {
            var dto = new TrainerDTO()
            {
                Fullname = "Jojo Jose",
                Email = "jojo@outlook.com",
                IsActive = true,
                Location = "Bengaluru",
                DateOfJoining = DateTime.Now,
                PhoneNumber = "1234512345",
                PrimarySkill = ".NET"
            };
            dto.Skills.Add(new SkillDTO
            {
                Name = "EF Core",
                Expertise = Expertise.Beginner,
                YearsOfExperience = 1
            });

            var repo = new Mock<IRepository<Trainer>>();
            repo.Setup(m => m.SaveAsync()).ReturnsAsync(1);
            var repoObj = repo.Object;

            var controller = new TrainersController(repoObj);

            var result = (StatusCodeResult)await controller.AddTrainer(dto).ConfigureAwait(false);
            Assert.That(result.StatusCode, Is.EqualTo(201));
        }

        [Test]
        public void Return_200StatusCode_WithDTO_ForValid_TrainerID()
        {
            var repo = new Mock<IRepository<Trainer>>();
            string name = "Jojo Jose";
            string phone = "12323123123";
            string email = "jojo@outlook.com";
            bool isActive = true;
            string location = "Hyderabad";
            DateTime doj = DateTime.Now;
            string pskill = ".NET";
            repo.Setup(m => m.GetBySpec(It.IsAny<SearchByIdAndIncludeSkillsSpecification>())).Returns(() =>
            {
                var trainer = new Trainer(name, phone, email, location, doj, isActive, pskill);
                return new List<Trainer>() { trainer };
            });
            var repoObj = repo.Object;
            var controller = new TrainersController(repoObj);
            OkObjectResult result = (OkObjectResult) controller.Get(1);
            Assert.That(result.StatusCode, Is.EqualTo(200));
            Assert.That(result.Value, Is.InstanceOf<TrainerDTO>());

            TrainerDTO dto = (TrainerDTO)result.Value;
            Assert.That(dto.Fullname, Is.EqualTo(name));
        }
    }
}
