﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserManagement.API
{
    public class Lead
    {
        public int Id { get; set; }
        public string ServiceLine { get; set; }
        public AppUser AppUser { get; set; }

    }
}
