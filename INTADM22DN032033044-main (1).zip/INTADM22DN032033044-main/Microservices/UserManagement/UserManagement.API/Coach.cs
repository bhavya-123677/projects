﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserManagement.API
{
    public class Coach
    {
        public int Id { get; set; }
        public string Location { get; set; }
        public AppUser AppUser { get; set; }
    }
}
