import { Link } from 'react-router-dom';
function Product(props) {
    const handleDelete = e => {
        e.preventDefault();
        const result = window.confirm('Are you sure you want to delete : '+props.prod.name);
        if(result){
            props.onProductDelete(props.prod.id);
        }
    }
    return <div className="card">
        <div className="card-body">
            <dl>
                <dt>Product Id</dt>
                <dd>{props.prod.id}</dd>

                <dt>Product Name</dt>
                <dd>{props.prod.name}</dd>

                <dt>Price</dt>
                <dd>{props.prod.price}</dd>
            </dl>
            <Link to={'/product-details/'+props.prod.id}>Details</Link> | 
            <Link to={'/product-edit/'+props.prod.id}>Edit</Link> | 
            <button className='m-4 btn btn-danger btn-sm' onClick={handleDelete}>Delete</button>
        </div>
    </div>
}
export default Product;