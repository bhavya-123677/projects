﻿using System;
using System.Collections.Generic;
using System.Text;
using TrainerManagement.Domain.Aggregates.TrainerAggregate;

namespace TrainerManagement.Domain.ValueObjects
{
    public class SkillExpertise : ValueObjectBase
    {
        protected SkillExpertise()
        {

        }
        public virtual Expertise Expertise { get; private set; }
        public virtual int YearsOfExperience { get; private set; }
        public SkillExpertise(Expertise expertise, int yearsOfExp)
        {
            this.Expertise = expertise;
            this.YearsOfExperience = yearsOfExp;
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Expertise;
            yield return YearsOfExperience;
        }
    }
}
