﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using ProductApiClient.Models;
using Newtonsoft.Json;
using System.Text;
namespace ProductApiClient.Controllers
{
    public class ProductsController : Controller
    {

        public async Task<IActionResult> Index()
        {
            List<Product> products = new List<Product>();
            string apiurl = "http://localhost:18236/";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiurl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync("api/products");
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string json = await response.Content.ReadAsStringAsync();
                    products = JsonConvert.DeserializeObject<List<Product>>(json);
                }
            }
            return View(products);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Product model)
        {
            if (!ModelState.IsValid)
                return View(model);

            string apiurl = "http://localhost:18236/";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiurl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                string json = JsonConvert.SerializeObject(model);
                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync("api/products", content);
                if (response.StatusCode == HttpStatusCode.Created)
                    return RedirectToAction("Index");
            }
            ModelState.AddModelError("", "Failed to save the object");
            return View(model);
        }

        public async Task<IActionResult> Details(int id)
        {
            Product product = new Product();
            string apiurl = "http://localhost:18236/";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiurl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync("api/products/" + id);
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string json = await response.Content.ReadAsStringAsync();
                    product = JsonConvert.DeserializeObject<Product>(json);
                }
            }
            return View(product);
        }

        public async Task<IActionResult> Edit(int id)
        {
            Product product = new Product();
            string apiurl = "http://localhost:18236/";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiurl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync("api/products/" + id);
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string json = await response.Content.ReadAsStringAsync();
                    product = JsonConvert.DeserializeObject<Product>(json);
                }
            }
            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Product model)
        {
            if (!ModelState.IsValid)
                return View(model);

            string apiurl = "http://localhost:18236/";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiurl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                string json = JsonConvert.SerializeObject(model);
                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PutAsync("api/products", content);
                if (response.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("Index");
            }
            ModelState.AddModelError("", "Failed to update the product");
            return View(model);
        }

        public async Task<IActionResult> Delete(int id)
        {
            Product product = new Product();
            string apiurl = "http://localhost:18236/";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiurl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync("api/products/" + id);
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string json = await response.Content.ReadAsStringAsync();
                    product = JsonConvert.DeserializeObject<Product>(json);
                }
            }
            return View(product);
        }

        [HttpPost]
        [ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            string apiurl = "http://localhost:18236/";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiurl);
                HttpResponseMessage response = await client.DeleteAsync("api/products/" + id);
                if (response.StatusCode == HttpStatusCode.NoContent)
                    return RedirectToAction("Index");
            }
            return RedirectToAction("Delete", new { id = id });
        }
    }
}
