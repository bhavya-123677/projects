﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TrainerManagement.Domain.DomainEvents;
using TrainerManagement.Domain.Services;

namespace TrainerManagement.Domain.EventHandlers
{
    public class TrainerCreatedEventHandler : INotificationHandler<TrainerCreatedEvent>
    {
        private readonly IEmailService emailService;
        public TrainerCreatedEventHandler(IEmailService email)
        {
            this.emailService = email;
        }
        public Task Handle(TrainerCreatedEvent notification, CancellationToken cancellationToken)
        {
            var body = $"<h1>Welcome {notification.FullName}</h1><br/>" +
                $"<p>You are onboarded to CTS</p>";
            emailService.SendEmail(notification.Email, "Welcome", body);
            return Task.CompletedTask;
        }
    }
}
