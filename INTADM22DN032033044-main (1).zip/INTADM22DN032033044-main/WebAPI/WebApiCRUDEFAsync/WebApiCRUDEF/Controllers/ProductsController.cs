﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCRUDEF.Models;

namespace WebApiCRUDEF.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ShopContext context;
        public ProductsController(ShopContext ctx)
        {
            this.context = ctx;
        }
        [HttpGet]
        [ProducesResponseType(200, Type =typeof(List<Product>))]
        public async Task<IActionResult> GetProducts()
        {
            var query = from item in context.Products
                        select item;
            var result = await query.ToListAsync();
            return Ok(result);
        }
        [HttpGet("{id}")]
        [ProducesResponseType(404)]
        [ProducesResponseType(200, Type =typeof(Product))]
        public async Task<IActionResult> GetProduct(int id)
        {
            var product = await context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            return Ok(product);
        }

        [HttpPost]
        [ProducesResponseType(400)]
        [ProducesResponseType(201)]
        public async Task<IActionResult> SaveProduct(Product obj)
        {
            context.Products.Add(obj);
            await context.SaveChangesAsync();
            return StatusCode(201);
        }

        [HttpPut]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(200, Type = typeof(Product))]
        public async Task<IActionResult> UpdateProduct(Product obj)
        {
            var product = await context.Products.FindAsync(obj.Id);
            if (product == null)
                return NotFound();

            product.Name = obj.Name;
            product.Price = obj.Price;
            await context.SaveChangesAsync();
            return Ok(product);
        }

        [HttpDelete("{id}")]
        [ProducesResponseType(404)]
        [ProducesResponseType(204)]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await context.Products.FindAsync(id);
            if (product == null)
                return NotFound();
            context.Products.Remove(product);
            await context.SaveChangesAsync();

            return NoContent();
        }
    }
}
