﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserManagement.API
{
    public class DataSeeder
    {
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly UserManager<AppUser> userManager;
        private readonly UserManagementContext context;
        public DataSeeder(RoleManager<IdentityRole> roleManager, UserManager<AppUser> userManager, UserManagementContext context)
        {
            this.roleManager = roleManager;
            this.userManager = userManager;
            this.context = context;
        }

        public async Task SeedRoles()
        {
            var role1 = new IdentityRole { Name = "Lead" };
            var role2 = new IdentityRole { Name = "Coach" };
            if (!await roleManager.RoleExistsAsync("Lead"))
                await roleManager.CreateAsync(role1);
            if (!await roleManager.RoleExistsAsync("Coach"))
                await roleManager.CreateAsync(role2);
        }
        public async Task SeedUsers()
        {
            var lead = new AppUser
            {
                FirstName = "Jojo",
                LastName = "Jose",
                Email = "jojo@outlook.com",
                UserName = "jojo@outlook.com",
                Gender = "Male",
                PhoneNumber = "1231231232"
            };
            var coach = new AppUser
            {
                FirstName = "Sam",
                LastName = "Jose",
                Email = "sam@outlook.com",
                UserName = "sam@outlook.com",
                Gender = "Female",
                PhoneNumber = "1345234567"
            };
            if (await userManager.FindByNameAsync("jojo@outlook.com") == null)
            {
                await userManager.CreateAsync(lead, "Jojo@1234");
                await userManager.AddToRoleAsync(lead, "Lead");
                var leaddetails = new Lead() { AppUser = lead, ServiceLine = "ADM" };
                context.Leads.Add(leaddetails);
                await context.SaveChangesAsync();
            }
            if (await userManager.FindByNameAsync("sam@outlook.com") == null)
            {
                await userManager.CreateAsync(coach, "Sam@1234");
                await userManager.AddToRoleAsync(coach, "Coach");
                var coachdeetails = new Coach() { AppUser = coach, Location = "Pune" };
                context.Coaches.Add(coachdeetails);
                await context.SaveChangesAsync();
            }
        }
    }
}
