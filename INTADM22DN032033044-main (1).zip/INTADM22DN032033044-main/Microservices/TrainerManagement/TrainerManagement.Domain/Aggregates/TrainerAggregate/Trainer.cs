﻿using System;
using System.Collections.Generic;
using System.Text;
using TrainerManagement.Domain.Entities;
using System.Linq;
using TrainerManagement.Domain.DomainEvents;

namespace TrainerManagement.Domain.Aggregates.TrainerAggregate
{
    public class Trainer : EntityBase, IAggregateRoot
    {
        public virtual string Fullname { get; private set; }
        public virtual string Email { get; private set; }
        public virtual string PhoneNumber { get; private set; }
        public virtual string Location { get; private set; }
        public virtual DateTime DateOfJoining { get; private set; }
        public virtual bool IsActive { get; private set; }
        public virtual string PrimarySkill { get; private set; }
        public virtual IList<Skill> SecondarySkills { get; set; } = new List<Skill>();
        public Trainer(string fullName, string phoneNumber, string email, string location, DateTime doj, bool isActive, string primarySkills)
        {
            this.Fullname = fullName;
            this.PhoneNumber = phoneNumber;
            this.Email = email;
            this.Location = location;
            this.DateOfJoining = doj;
            this.IsActive = IsActive;
            this.PrimarySkill = primarySkills;
            var trainerAdded = new TrainerCreatedEvent()
            {
                Email = this.Email,
                PhoneNumber = this.PhoneNumber,
                FullName = this.Fullname
            };
            base.DomainEvents.Add(trainerAdded);
        }
        protected Trainer() { }

        public void ChangeEmail(string newEmail)
        {
            if (string.IsNullOrEmpty(newEmail) || !newEmail.Contains("@"))
                throw new ArgumentException("Invalid email");

            if (this.Email == newEmail)
                return;
            this.Email = newEmail;
        }
        public void ChangePhoneNumber(string newPhoneNumber)
        {
            if (string.IsNullOrEmpty(newPhoneNumber) || !(newPhoneNumber.Length == 10))
                throw new ArgumentException("Invalid newPhoneNumber");

            if (this.PhoneNumber == newPhoneNumber)
                return;
            this.PhoneNumber = newPhoneNumber;
        }
        public void AddSkill(Skill newSkill)
        {
            this.SecondarySkills.Add(newSkill);
        }
        public void RemoveSkill(long skillId)
        {
            var skill = SecondarySkills.First(s => s.Id == skillId);
            this.SecondarySkills.Remove(skill);
        }
    }
}
