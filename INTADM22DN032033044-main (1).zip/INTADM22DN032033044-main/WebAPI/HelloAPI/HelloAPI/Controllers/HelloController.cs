﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelloAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HelloController : ControllerBase
    {
        [HttpGet]
        public IActionResult SayHello()
        {
            return Ok("Hello there !!");
        }
        [HttpPost]
        public IActionResult Method01()
        {
            return Ok("Method 01 executed");
        }
        [HttpPut]
        public IActionResult Method02()
        {
            return Ok("Method 02 executed");
        }
        [HttpDelete]
        public IActionResult Method03()
        {
            return Ok("Method 03 executed");
        }
    }
}
