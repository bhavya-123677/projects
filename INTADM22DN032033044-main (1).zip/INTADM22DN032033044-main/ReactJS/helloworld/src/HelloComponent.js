import react from 'react';
import './HelloComponent.css';
// function Hello() {
//     let firstName = 'Khaleelullah';
//     let middleName = 'Hussaini';
//     let lastName = 'Syed';
//     const getFullName = () => {
//         return firstName + ' ' + middleName + ' ' + lastName;
//     }
//     return (
//         // <h1>Khaleelullah Hussaini Syed</h1>
//         //<h1>{firstName} {middleName} {lastName}</h1>
//         // <h1>{firstName + ' ' + middleName+ ' '+lastName}</h1>
//         // <h1 className='text-center' style={{"backgroundColor":"aliceblue", "fontStyle":"italic"}}>{getFullName()}</h1>
//         <h1 className='bg-dark text-light'>{getFullName()}</h1>
//     );
// }
class Hello extends react.Component {
    firstName = 'Khaleelullah';
    middleName = 'Hussaini';
    lastName = 'Syed';
    getFullName = () => {
        return this.firstName + ' ' + this.middleName + ' ' + this.lastName;
    }
    render() {
        <h1 className='bg-dark text-light'>{this.getFullName()}</h1>
    }
}
export default Hello;