﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrainerManagement.Domain.DomainEvents
{
    public class TrainerCreatedEvent : EventBase
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
    }
}
