function Success(props) {
   // let message = "Operation completed successfully";
    return <div className="row">
        <div className="col">
            <div className="alert alert-success">{props.successMessage}</div>
        </div>
    </div>
}
export default Success;