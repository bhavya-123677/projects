﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.IO;
namespace WebApiCRUDEF.Filters
{
    public class MyUnHandledExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            using (var fs = new FileStream("ExceptionsLog.log", FileMode.Append, FileAccess.Write))
            using (var sw = new StreamWriter(fs))
            {
                sw.WriteLine($"--------------------Exception happened at {DateTime.UtcNow}");
                sw.WriteLine($"Error Message : {context.Exception.Message}");
                sw.WriteLine($"StackTrace :  {context.Exception.StackTrace}");
                sw.Close();
                fs.Close();
                context.ExceptionHandled = true;
            }  
        }
    }
}
