﻿using System;
using System.Collections.Generic;
using System.Text;
using TrainerManagement.Domain.Aggregates;
using TrainerManagement.Domain.Entities;
using System.Linq.Expressions;
using System.Linq;
namespace TrainerManagement.Domain.Specifications
{
    public abstract class SpecificationBase<T> where T: EntityBase, IAggregateRoot
    {
        public abstract Expression<Func<T, bool>> ToExpression();
        public List<string> Includes { get; } = new List<string>();
    }
}
