﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrainerManagement.Domain.Aggregates
{
    public interface IAggregateRoot
    {
    }
}
