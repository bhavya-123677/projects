﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using WebApiCRUDEF.Models;
namespace WebApiCRUDEF.Specifications
{
    public class SearchProductByNameSpecification : SpecificationBase<Product>
    {
        private string productName;
        public SearchProductByNameSpecification(string productName)
        {
            this.productName = productName;
        }
        public override Expression<Func<Product, bool>> ToExpression()
        {
            return obj => obj.Name.Contains(productName);
        }
    }
}
