import logo from './logo.svg';
import './App.css';
import react from 'react';
function App() {
  return (
    // <h1>Hello React</h1>
    // react.createElement('h1',null,"Hello React")

    // <div>
    //   <h1>Hello React</h1>
    //   <h2>Hello CTS</h2>
    // </div>
    //or
    <>
      <h1>Hello React</h1>
      <h2>Hello CTS</h2>
    </>
  );
}

export default App;
