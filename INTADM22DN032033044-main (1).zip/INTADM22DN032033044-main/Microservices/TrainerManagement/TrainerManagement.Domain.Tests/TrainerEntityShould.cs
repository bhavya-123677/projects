﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit;
using NUnit.Framework;
using TrainerManagement.Domain;
using TrainerManagement.Domain.Entities;
using TrainerManagement.Domain.Aggregates;
using TrainerManagement.Domain.Aggregates.TrainerAggregate;
namespace TrainerManagement.Domain.Tests
{
    [TestFixture]
    public class TrainerEntityShould
    {
        [Test]
        public void Create_NewTrainer_ViaConstructor()
        {
            //Arrange
            string name = "Jojo Jose";
            string phone = "12323123123";
            string email = "jojo@outlook.com";
            bool isActive = true;
            string location = "Hyderabad";
            DateTime doj = DateTime.Now;
            string pskill = ".NET";

            //Act
            var trainer = new Trainer(name, phone, email, location, doj, isActive, pskill);

            //Assert
            Assert.That(trainer, Is.Not.Null);
            Assert.That(trainer, Is.InstanceOf<Trainer>());
            Assert.That(trainer.Fullname, Is.EqualTo(name));
            Assert.That(trainer.PhoneNumber, Is.EqualTo(phone));
            Assert.That(trainer.Email, Is.EqualTo(email));
        }

        [Test]
        public void Update_EmailAddress()
        {
            //Arrange
            string name = "Jojo Jose";
            string phone = "12323123123";
            string email = "jojo@outlook.com";
            bool isActive = true;
            string location = "Hyderabad";
            DateTime doj = DateTime.Now;
            string pskill = ".NET";
            var trainer = new Trainer(name, phone, email, location, doj, isActive, pskill);

            //Act
            trainer.ChangeEmail("jojojose@outlook.com");

            //Assert
            Assert.That(trainer.Email, Is.EqualTo("jojojose@outlook.com"));
        }

        [Test]
        [TestCase("")]
        [TestCase(null)]
        [TestCase("jojo.com")]
        public void Throws_ArgumentException_For_InvalidEmail(string input)
        {
            //Arrange
            string name = "Jojo Jose";
            string phone = "12323123123";
            string email = "jojo@outlook.com";
            bool isActive = true;
            string location = "Hyderabad";
            DateTime doj = DateTime.Now;
            string pskill = ".NET";
            var trainer = new Trainer(name, phone, email, location, doj, isActive, pskill);

            Assert.Throws<ArgumentException>(() => trainer.ChangeEmail(input));
        }
    }
}
