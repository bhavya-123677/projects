﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DependencyLifetimes
{
    public class ClassOne
    {
        private readonly ClassDep dep;
        public ClassOne(ClassDep d)
        {
            this.dep = d;
        }
        public int GetIntanceCount()
        {
            return ClassDep.totalinstances;
        }
    }
}
