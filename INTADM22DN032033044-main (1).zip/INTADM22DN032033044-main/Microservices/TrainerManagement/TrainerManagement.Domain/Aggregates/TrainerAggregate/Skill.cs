﻿using System;
using System.Collections.Generic;
using System.Text;
using TrainerManagement.Domain.Entities;
using TrainerManagement.Domain.ValueObjects;

namespace TrainerManagement.Domain.Aggregates.TrainerAggregate
{
    public class Skill : EntityBase
    {
        public virtual string Name { get; private set; }
        public virtual SkillExpertise SkillExpertise { get; private set; }
        public Skill(string name, SkillExpertise skillExpertise)
        {
            this.Name = name;
            this.SkillExpertise = skillExpertise;
        }
        protected Skill() { }
       
    }
}
