﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using TrainerManagement.Domain.Aggregates.TrainerAggregate;

namespace TrainerManagement.Infrastructure.Data.Config
{
    public class SkillEntityTypeConfiguration : IEntityTypeConfiguration<Skill>
    {
        public void Configure(EntityTypeBuilder<Skill> builder)
        {
            builder.HasKey(p => p.Id);
            builder.OwnsOne(p => p.SkillExpertise);
            builder.Property(p => p.Name).IsRequired(true).HasMaxLength(30);
           
        }
    }
}
