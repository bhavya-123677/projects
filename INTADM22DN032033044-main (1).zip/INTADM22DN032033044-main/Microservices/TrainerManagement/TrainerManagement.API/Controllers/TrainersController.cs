﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TrainerManagement.API.Converters;
using TrainerManagement.API.DTOs;
using TrainerManagement.Domain.Aggregates.TrainerAggregate;
using TrainerManagement.Domain.Interfaces;
using TrainerManagement.Domain.ValueObjects;

namespace TrainerManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrainersController : ControllerBase
    {
        private readonly IRepository<Trainer> trainerRepository;

        public TrainersController(IRepository<Trainer> trainerRepository)
        {
            this.trainerRepository = trainerRepository;
        }

        [HttpPost]
        [ProducesResponseType(201)]
        [Authorize(Roles = "Lead")]
        public async Task<IActionResult> AddTrainer(TrainerDTO dto)
        {
            var trainer = new Trainer(dto.Fullname, dto.PhoneNumber, dto.Email, dto.Location, dto.DateOfJoining, dto.IsActive, dto.PrimarySkill);
            Skill skill = null;
            SkillExpertise expertise = null;
            foreach (var skillDTO in dto.Skills)
            {
                expertise = new SkillExpertise(skillDTO.Expertise, skillDTO.YearsOfExperience);
                skill = new Skill(skillDTO.Name, expertise);
                trainer.AddSkill(skill);
            }
            trainerRepository.Add(trainer);
            await trainerRepository.SaveAsync();
            return StatusCode(201);
        }

        [HttpGet]
        [ProducesResponseType(200, Type = typeof(List<TrainerDTO>))]
        [Authorize(Roles = "Coach,Lead")]
        public IActionResult GetTrainers()
        {
            var trainers = trainerRepository.Get();
            var dtos = from trainer in trainers
                       select new TrainerDTO
                       {
                           Id = trainer.Id,
                           Fullname = trainer.Fullname,
                           Email = trainer.Email,
                           IsActive = trainer.IsActive,
                           DateOfJoining = trainer.DateOfJoining,
                           Location = trainer.Location,
                           PhoneNumber = trainer.PhoneNumber,
                           PrimarySkill = trainer.PrimarySkill
                       };
            return Ok(dtos);
        }
       
        [HttpGet("{trainerId}")]
        [ProducesResponseType(404)]
        [ProducesResponseType(200, Type = typeof(TrainerDTO))]
        [Authorize(Roles = "Coach, Lead")]
        public IActionResult Get(long trainerId)
        {
            var spec = new SearchByIdAndIncludeSkillsSpecification(trainerId);
            var trainers = trainerRepository.GetBySpec(spec);
            if (trainers.Count == 0)
                return NotFound();

            var trainer = trainers.First();
            var trainerDto = new TrainerDTO()
            {
                Id = trainer.Id,
                Fullname = trainer.Fullname,
                Email = trainer.Email,
                PhoneNumber = trainer.PhoneNumber,
                DateOfJoining = trainer.DateOfJoining,
                IsActive = trainer.IsActive,
                Location = trainer.Location,
                PrimarySkill = trainer.PrimarySkill
            };
            SkillDTO skillDto = null;
            foreach (var skill in trainer.SecondarySkills)
            {
                skillDto = new SkillDTO()
                {
                    Id = skill.Id,
                    Name = skill.Name,
                    Expertise = skill.SkillExpertise.Expertise,
                    YearsOfExperience = skill.SkillExpertise.YearsOfExperience
                };
                trainerDto.Skills.Add(skillDto);
            }
            return Ok(trainerDto);
        }

        [HttpGet("search/{skill}")]
        [ProducesResponseType(404)]
        [ProducesResponseType(200, Type = typeof(TrainerDTO[]))]
        [Authorize(Roles = "Coach, Lead")]
        public IActionResult GetBySkill(string skill)
        {
            var spec = new SearchBySkillSpecification(skill);
            var trainers = trainerRepository.GetBySpec(spec);
            if (trainers.Count == 0)
                return NotFound();
            List<TrainerDTO> dtos = new List<TrainerDTO>();
            TrainerDTO trainerDTO = null;
            SkillDTO skillDTO = null;
            foreach(var trainer in trainers)
            {
                trainerDTO = TrainerDTOConverter.ToTrainerDTO(trainer);
                foreach(var skillObj in trainer.SecondarySkills)
                {
                    skillDTO = SkillDTOConverter.ToSkillDTO(skillObj);
                    trainerDTO.Skills.Add(skillDTO);
                }
                dtos.Add(trainerDTO);
            }
            return Ok(dtos);
        }

        [HttpPut("{id}/updatephone")]
        [ProducesResponseType(404)]
        [ProducesResponseType(200, Type =(typeof(TrainerDTO)))]
        [Authorize(Roles = "Lead")]
        public async Task<IActionResult> UpdatePhone(long id, [FromBody]string phoneNumber)
        {
            var trainer = trainerRepository.GetById(id);
            if (trainer == null)
                return NotFound();
            trainer.ChangePhoneNumber(phoneNumber);
            trainerRepository.Update(trainer);
            await trainerRepository.SaveAsync();

            var dto = TrainerDTOConverter.ToTrainerDTO(trainer);
            return Ok(dto);
        }

        [HttpPut("{id}/updateemail")]
        [ProducesResponseType(404)]
        [ProducesResponseType(200, Type = (typeof(TrainerDTO)))]
        [Authorize(Roles ="Lead")]
        public async Task<IActionResult> UpdateEmail(long id, [FromBody] string email)
        {
            var trainer = trainerRepository.GetById(id);
            if (trainer == null)
                return NotFound();
            trainer.ChangeEmail(email);
            trainerRepository.Update(trainer);
            await trainerRepository.SaveAsync();

            var dto = TrainerDTOConverter.ToTrainerDTO(trainer);
            return Ok(dto);
        }

        [HttpDelete("{id}/deleteskill/{skillid}")]
        [ProducesResponseType(404)]
        [ProducesResponseType(204)]
        [Authorize(Roles="Lead")]
        public async Task<IActionResult> DeleteSkill(long id, long skillid)
        {
            var spec = new SearchByIdAndIncludeSkillsSpecification(id);
            var trainers = trainerRepository.GetBySpec(spec);
            if (trainers.Count == 0)
                return NotFound();
            var trainer = trainers.First();
            trainer.RemoveSkill(skillid);
            await trainerRepository.SaveAsync();
            return StatusCode(204);
        }
    }
}
