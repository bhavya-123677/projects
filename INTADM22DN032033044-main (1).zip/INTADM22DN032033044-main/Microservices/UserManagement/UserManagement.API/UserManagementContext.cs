﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserManagement.API
{
    public class UserManagementContext : IdentityDbContext<AppUser>
    {
        public DbSet<Lead> Leads { get; set; }
        public DbSet<Coach> Coaches { get; set; }
        public UserManagementContext(DbContextOptions options) : base(options)
        {
        }
    }
}
