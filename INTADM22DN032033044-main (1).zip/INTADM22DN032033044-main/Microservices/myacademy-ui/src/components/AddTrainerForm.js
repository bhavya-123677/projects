import { useState } from "react";
import TrainersService from '../services/TrainersService';
const AddTrainerForm = props => {
    const [trainer, setTrainer] = useState({
        fullname: '',
        email: '',
        phoneNumber: '',
        location: '',
        dateOfJoining: new Date(),
        isActive: false,
        primarySkill: '',
        skills: []
    })
    const [skill, setSkill] = useState({ skillname: '', expertise: '', yearsOfExperience: 0 })
    const handleTrainerDetailsChange = ev => {
        let { name, value, type } = ev.target;
        if (type === 'date')
            value = new Date(value);
        if (type === 'checkbox')
            value = ev.target.checked;
        setTrainer({ ...trainer, [name]: value });
    }
    const handleSkillDetailsChange = ev => {
        let { name, value, type } = ev.target;
        console.log(type);
        if (type === 'number' || type === 'select-one')
            value = parseFloat(value);
        setSkill({ ...skill, [name]: value });
    }
    const handleAddSkill = ev => {
        ev.preventDefault();
        const sk = { name: skill.skillname, expertise: skill.expertise, yearsOfExperience: skill.yearsOfExperience };
        console.log(sk);
        const trainerSkills = [...trainer.skills];
        trainerSkills.push(sk);
        console.log(trainerSkills);
        setTrainer({ ...trainer, skills: trainerSkills });
        setSkill({ skillname: '', expertise: '', yearsOfExperience: 0 })
    }
    const handleSubmit = ev => {
        ev.preventDefault();
        TrainersService.addNewTrainer(trainer).then(res => {
            alert('Trainer added');
        }).catch(res => { });
    }
    return <div className="row">
        <div className="col-12">
            <h2>Create a new trainer</h2>
            <form method="post" onSubmit={handleSubmit}>
                <div className="row">
                    <div className="col">
                        <input type="text"
                            className="form-control"
                            placeholder="Enter full name"
                            id="fullname"
                            name="fullname"
                            value={trainer.fullname}
                            onChange={handleTrainerDetailsChange} />
                    </div>
                    <div className="col">
                        <input type="email"
                            className="form-control"
                            placeholder="Enter Email"
                            id="email"
                            name="email"
                            value={trainer.email}
                            onChange={handleTrainerDetailsChange} />
                    </div>
                    <div className="col">
                        <input type="phone"
                            className="form-control"
                            placeholder="Enter Phone number"
                            id="phoneNumber"
                            name="phoneNumber"
                            value={trainer.phoneNumber}
                            onChange={handleTrainerDetailsChange} />
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col">
                        <select className="form-control"
                            id="location"
                            name="location"
                            value={trainer.location}
                            onChange={handleTrainerDetailsChange}>
                            <option value="Hyderabad">Hyderabad</option>
                            <option value="Pune">Pune</option>
                            <option value="Chennai">Chennai</option>
                            <option value="Bengaluru">Bengaluru</option>
                        </select>
                    </div>
                    <div className="col">
                        <input type="date"
                            className="form-control"
                            placeholder="Enter Date of Joining"
                            id="dateOfJoining"
                            name="dateOfJoining"
                            value={trainer.dateOfJoining.toLocaleDateString()}
                            onChange={handleTrainerDetailsChange} />
                    </div>
                    <div className="col">
                        <select className="form-control"
                            id="primarySkill"
                            name="primarySkill"
                            value={trainer.primarySkill}
                            onChange={handleTrainerDetailsChange}>
                            <option value=".NET">.NET</option>
                            <option value="Java">Java</option>
                            <option value="Dataware Housing">Dataware Housing</option>
                            <option value="Python">Python</option>
                        </select>
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col">
                        <div className="form-check">
                            <input className="form-check-input"
                                type="checkbox"
                                id="isActive"
                                name="isActive"
                                checked={trainer.isActive}
                                onChange={handleTrainerDetailsChange} />
                            <label className="form-check-label" htmlFor="flexCheckDefault">
                                Is Active (yes/no)
                            </label>
                        </div>
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col">
                        <input type="text"
                            className="form-control"
                            placeholder="Enter skill name"
                            id="skillname"
                            name="skillname"
                            value={skill.skillname}
                            onChange={handleSkillDetailsChange} />
                    </div>
                    <div className="col">
                        <input type="number"
                            className="form-control"
                            placeholder="Enter years of exp"
                            id="yearsOfExperience"
                            name="yearsOfExperience"
                            value={skill.yearsOfExperience}
                            onChange={handleSkillDetailsChange} />
                    </div>
                    <div className="col">
                        <select className="form-control"
                            id="expertise"
                            name="expertise"
                            value={skill.expertise}
                            onChange={handleSkillDetailsChange} >
                            <option value="0">Beginner</option>
                            <option value="1">Intermediate</option>
                            <option value="2">Advanced</option>
                        </select>
                    </div>
                    <div className="col">
                        <button type="button"
                            className="btn btn-sm btn-primary"
                            onClick={handleAddSkill}>Add Skill</button>
                    </div>
                </div>
                <div className="row">
                    <div className="col">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Skill name</th>
                                    <th>Year of Exp</th>
                                    <th>Expertise</th>
                                </tr>
                            </thead>
                            <tbody>
                                {trainer.skills?.map(s => <tr key={s.name}>
                                    <td>{s.name}</td>
                                    <td>{s.yearsOfExperience}</td>
                                    <td>{s.expertise}</td>
                                </tr>)}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="row">
                    <div className="col">
                        <button type="submit"
                            className="btn btn-lg btn-primary">
                            Add Trainer
                        </button>
                    </div>
                </div>
            </form>

        </div>
    </div>
}
export default AddTrainerForm;