﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DependencyLifetimes.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ClassOne one;
        private readonly ClassTwo two;
        public WeatherForecastController(ClassOne one, ClassTwo two)
        {
            this.one = one;
            this.two = two;
        }
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(one.GetIntanceCount());
        }
    }
}
