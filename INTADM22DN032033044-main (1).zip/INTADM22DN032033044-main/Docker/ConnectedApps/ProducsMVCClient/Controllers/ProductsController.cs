﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using Newtonsoft.Json;

namespace ProducsMVCClient.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IConfiguration configuration;

        public ProductsController(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public async Task<IActionResult> Index()
        {
            var api = configuration["apiurl"];
            var client = new HttpClient();
            client.BaseAddress = new Uri(api);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await client.GetAsync("/api/products");
            var content = await response.Content.ReadAsStringAsync();
            var data =  JsonConvert.DeserializeObject<List<Product>>(content);
            return View(data);
        }
    }
}
