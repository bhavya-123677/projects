﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace WebApiCRUDEF.Specifications
{
    public abstract class SpecificationBase<TEntity> where TEntity : class
    {
        public abstract Expression<Func<TEntity, bool>> ToExpression();
    }
}
