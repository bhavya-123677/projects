import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom'
import axios from 'axios';
export function ProductDetails(props) {
    let { id } = useParams();
    let navigate = useNavigate();
    const handleClick = ev => {
        ev.preventDefault();
        navigate('/');
    }

    const [productObj, setProductObj] = useState({});
    const getProductById = pid => {
        axios.get('http://localhost:18236/api/products/' + pid)
            .then(r => {
                setProductObj({ ...r.data });
            })
            .catch(r => {
                if (r.response.status == 404) {
                    alert('No such product found');
                }
            });
    }
    useEffect(()=>{
        getProductById(id);
    },[]);
    return <div className="row">
        <div className="col-md-6">
            <h1>Product details</h1>
            <dl>
                <dt>Product ID</dt>
                <dd>{productObj.id}</dd>
                <dt>Product Name</dt>
                <dd>{productObj.name}</dd>
                <dt>Product Price</dt>
                <dd>{productObj.price}</dd>
            </dl>
            <button type="button" className="btn btn-link" onClick={handleClick}>Back to list</button>
        </div>

    </div>

}