﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCRUDEF.Models;
using WebApiCRUDEF.Specifications;

namespace WebApiCRUDEF.Repositories
{
    public class GenericRepository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        private readonly ShopContext context;
        public GenericRepository(ShopContext context)
        {
            this.context = context;
        }
        public TEntity Add(TEntity item) 
        {
            return context.Add(item).Entity;
        }

        public TEntity Update(TEntity item)
        {
            return context.Update(item).Entity;
        }

        public TEntity Remove(TEntity item)
        {
            return context.Remove(item).Entity;
        }

        public async Task<int> SaveAsync()
        {
            return await context.SaveChangesAsync();
        }

        public async Task<TEntity> GetByIdAsync(int id)
        {
            return await context.Set<TEntity>().FindAsync(id);
        }

        public IReadOnlyCollection<TEntity> GetAll()
        {
            var Data = context.Set<TEntity>().ToList();
            return Data.AsReadOnly();
        }

        public IReadOnlyCollection<TEntity> GetBySpec(SpecificationBase<TEntity> spec)
        {
            var Set = context.Set<TEntity>();
            var Query = Set.Where(spec.ToExpression().Compile());
            return Query.ToList().AsReadOnly();
        }
    }
}
