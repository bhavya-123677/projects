﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using TrainerManagement.Domain.Aggregates.TrainerAggregate;

namespace TrainerManagement.API.DTOs
{
    public class SkillDTO
    {
        public long Id { get; set; }
        [Required]
        public string Name { get;  set; }
        public Expertise Expertise { get;  set; }
        public int YearsOfExperience { get;  set; }
    }
}
