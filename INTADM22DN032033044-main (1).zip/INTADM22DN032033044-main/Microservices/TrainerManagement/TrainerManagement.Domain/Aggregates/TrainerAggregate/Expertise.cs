﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrainerManagement.Domain.Aggregates.TrainerAggregate
{
    public enum Expertise
    {
        Beginner, Intermediate, Expert
    }
}
