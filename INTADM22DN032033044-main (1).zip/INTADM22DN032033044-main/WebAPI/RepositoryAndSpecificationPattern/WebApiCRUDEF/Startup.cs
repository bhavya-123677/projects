using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCRUDEF.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using WebApiCRUDEF.Repositories;
namespace WebApiCRUDEF
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();
            string constr = Configuration.GetConnectionString("DefaultCon");
            services.AddControllers().AddXmlSerializerFormatters();
            services.AddDbContext<ShopContext>(context => context.UseSqlServer(constr));
            services.AddScoped<IRepository<Product>, GenericRepository<Product>>();
            services.AddSwaggerGen(options => options.SwaggerDoc("v1", new OpenApiInfo()
            {
                Title = "Products API",
                Description = "Allows wokring with product information in database",
                TermsOfService = new Uri("http://www.cognizant.com"),
                Contact = new OpenApiContact()
                {
                    Name = "Khaleelullah Hussaini Syed",
                    Email = "techiesyed@outlook.com",
                    Url = new Uri("https://github.com/techiesyed")
                }
            }));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseCors(options =>
            {
                options.AllowAnyOrigin();   //accept request from all client
                options.AllowAnyMethod();   //support all http operations like get, post, put, delete
                options.AllowAnyHeader();   //support all http headers like content-type, accept, etc

                //options.WithOrigins("http://www.google.com", "http://www.cognizant.com");
                //options.WithMethods("GET", "POST");
                //options.WithHeaders("Authorization", "Content-Type");
            });
            app.UseSwagger();
            app.UseSwaggerUI(options => options.SwaggerEndpoint("v1/swagger.json", "Products API"));
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
