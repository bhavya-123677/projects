import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom'
import axios from 'axios'
export function EditProduct(props) {
    let { productId } = useParams();
    const [productObj, setProductObj] = useState({ id: 0, name: '', price: 0 });
    const getProductById = pid => {
        axios.get('http://localhost:18236/api/products/' + pid).then(r => {
            setProductObj({ ...r.data });
        }).catch(r => {
            console.log(r.response.status);
        });
    }
    useEffect(() => {
        getProductById(productId);
    }, []);
    const handleUpdate = (ev) => {
        ev.preventDefault();
        axios.put('http://localhost:18236/api/products/', { ...productObj }).then(r => {
            if (r.status == 200) {
                alert('Product details updated');
            }
        }).catch(r => {
            console.log(r.reponse.status);
        });
    }
    const handleChange = (ev) => {
        let { name, value, type } = ev.target;
        if (type === 'number')
            value = parseFloat(value);
        setProductObj({ ...productObj, [name]: value });
    }
    return <div className="row">
        <div className="col-md-6">
            <h1>Edit product details</h1>
            <form method="post" onSubmit={handleUpdate}>
                <div className='form-group'>
                    <label htmlFor='id'>Product Id</label>
                    <input type="number"
                        id="id"
                        name="id"
                        className='form-control'
                        value={productObj.id}
                        readOnly />
                </div>
                <div className='form-group'>
                    <label htmlFor='name'>Product Name</label>
                    <input type="text"
                        id="name"
                        name="name"
                        className='form-control'
                        value={productObj.name}
                        onChange={handleChange}
                        required />
                </div>
                <div className='form-group'>
                    <label htmlFor='price'>Product Price</label>
                    <input type="number"
                        id="price"
                        name="price"
                        className='form-control'
                        value={productObj.price}
                        onChange={handleChange}
                        required />
                </div>
                <div className='form-group mt-2'>
                    <button type="submit"
                        className='btn btn-primary'>
                        Update Product
                    </button>
                </div>
            </form>
        </div>
    </div>
}