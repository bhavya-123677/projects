﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using WebApiCRUDEF.Models;

namespace WebApiCRUDEF.Specifications
{
    public class FilterProductsByPriceRangeSpecification : SpecificationBase<Product>
    {
        private decimal minimumPrice;
        private decimal maximumPrice;
        public FilterProductsByPriceRangeSpecification(decimal minimumPrice, decimal maximumPrice)
        {
            this.minimumPrice = minimumPrice;
            this.maximumPrice = maximumPrice;
        }
        public override Expression<Func<Product, bool>> ToExpression()
        {
            return p => p.Price >= minimumPrice && p.Price <= maximumPrice;
        }
    }
}
