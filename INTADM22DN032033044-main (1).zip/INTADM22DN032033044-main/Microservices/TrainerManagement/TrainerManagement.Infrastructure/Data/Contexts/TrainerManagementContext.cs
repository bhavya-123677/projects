﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainerManagement.Domain.Aggregates.TrainerAggregate;
using TrainerManagement.Domain.Entities;
using MediatR;
using System.Threading;

namespace TrainerManagement.Infrastructure.Data.Contexts
{
    public class TrainerManagementContext : DbContext
    {
        private readonly IMediator mediator;
        public TrainerManagementContext(DbContextOptions options, IMediator mediator) : base(options)
        {
            this.mediator = mediator;
        }
        public virtual DbSet<Trainer> Trainers { get; set; }
        public virtual DbSet<Skill> Skills { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


            modelBuilder.ApplyConfigurationsFromAssembly(typeof(TrainerManagementContext).Assembly);
        }
        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            int rows = await base.SaveChangesAsync(cancellationToken);
            var Entities = ChangeTracker.Entries().Select(e => e.Entity as EntityBase).ToArray();
            foreach (var entity in Entities)
            {

                var events = entity?.DomainEvents;
                if (events != null)
                {
                    foreach (var ev in events)
                    {
                        await mediator.Publish(ev).ConfigureAwait(false);
                    }
                    entity.DomainEvents.Clear();
                }

            }
            return rows;
        }
    }
}
