import React from "react";
class Error extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return <div className="row">
        <div className="col">
            <div className="alert alert-danger">{this.props.errorMessage}</div>
        </div>
    </div>
    }
}
export default Error;