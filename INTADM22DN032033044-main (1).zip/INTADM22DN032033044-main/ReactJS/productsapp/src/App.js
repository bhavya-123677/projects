import logo from './logo.svg';
import './App.css';
import Success from './SuccessComponent';
import Error from './ErrorComponent';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ProductList from './ProductListComponent';
import { AddProduct } from './AddProductComponent';
import { Like } from './LikeComponent';
import { NavBar } from './NavBarComponent';
import { ProductDetails } from './ProductDetailsComponent';
import { EditProduct } from './EditProductComponent';
function App() {
  return (
    <Router>
      <NavBar />
      <div className="container">
        <div className="row">
          <div className="col">
            <Routes>
              <Route path='/' element={<ProductList />} />
              <Route path='/add-product' element={<AddProduct />} />
              <Route path='/likes' element={<Like />} />
              <Route path='/product-details/:id' element={<ProductDetails/>}/>
              <Route path='/product-edit/:productId' element={<EditProduct/>}/>
            </Routes>
          </div>
        </div>
      </div >
    </Router>

  );
}

export default App;
